Данные представляют собой статьи с lenta.ru за последнее время - для разных рубрик от последних нескольких месяцев до последних нескольких лет (самое раннее - конец 2015 года). Данные разделены на 20 рубрик - рубрики можно посмотреть по ссылкам https://lenta.ru/rubrics/первыйуровеньрубрики/второйуровеньрубрики

Распределение по темам:
culture: 1000 texts, 292000 words
economics_companies: 1000 texts, 335563 words
economics_economy: 1000 texts, 234414 words
economics_finance: 799 texts, 202468 words
forces_investigations: 1000 texts, 266220 words
forces_violation: 1000 texts, 210634 words
life_accident: 1000 texts, 189339 words
life_animals: 1000 texts, 158500 words
life_food: 206 texts, 45780 words
russia_accident: 1009 texts, 133954 words
science_cosmos: 1000 texts, 234185 words
science_gadget: 852 texts, 204089 words
science_history: 551 texts, 434982 words
science_mil: 1000 texts, 184463 words
science_natural: 350 texts, 64593 words
science_science: 1000 texts, 238294 words
sport: 1000 texts, 210055 words
style_look: 1000 texts, 304069 words
travel: 1000 texts, 290219 words
world_politic: 1010 texts, 258312 words

Если вам что-то не нравится в данных, говорите, обсудим. Напоминаю, что можно собрать свои, а можете дособрать эти, если необходимо, а можете что-то выкинуть, если это кажется вам мусором.


Еще больше данных (конец 2015 - конец 2013)
https://drive.google.com/file/d/1ESGURYDmwQrsDuDYGCScqH76oHf5chKN/view?usp=sharing
{'culture': 9549,
 'economics_companies': 3243,
 'economics_economy': 5890,
 'economics_finance': 697,
 'forces_investigations': 1518,
 'forces_violation': 580,
 'life_accident': 934,
 'life_animals': 746,
 'life_food': 292,
 'russia_accident': 2075,
 'science_cosmos': 1554,
 'science_gadget': 1500,
 'science_mil': 3,
 'science_science': 3414,
 'sport': 7887,
 'style_look': 160,
 'travel': 383,
 'world_politic': 6206}
